EditorListScrolling


Changes in 1.2:
-fixed the strange visual scrolling of the categories and filters.

Changes in 1.1:
-works now with custom filters and subassemblies
-fixed tooltips
-config now contains explanations of the settings


Features 1.0:
-enables scrolling via mousewheel in the partlist, filters and categories in the editor.
-works with Stock Filters
-works Filter Extensions mod


Knwon Issues:
-None


Sourcecode:
https://github.com/Alewx/EditorListScrolling


Special Thanks to
-Crzyrndm for pointing out the basics of the Filter selection to me.
-Malah for hinting me at the tooptips solution and custom filters.




Code and artworks are licensed under the Attribution-NonCommercial-ShareAlike 4.0 (CC BY-NC-SA 4.0)
creative commons license. See http://creativecommons.org/licenses/by-nc-sa/4.0/legalcode for full details.

The rights to subsequent code and artworks belongs to Alewx