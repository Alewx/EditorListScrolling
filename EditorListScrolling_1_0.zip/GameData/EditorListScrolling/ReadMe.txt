EditorListScrolling


Features 1.0:
-enables scrolling via mousewheel in the partlist, filters and categories in the editor.
-works with Stock Filters
-works Filter Extensions mod


Knwon Issues:
-works not on Custom Filters or Subassemblies




Code and artworks are licensed under the Attribution-NonCommercial-ShareAlike 4.0 (CC BY-NC-SA 4.0)
creative commons license. See http://creativecommons.org/licenses/by-nc-sa/4.0/legalcode for full details.

The rights to subsequent code and artworks belongs to Alewx


Special Thanks to Crzyrndm for pointing out the basics of the Filter selection to me.